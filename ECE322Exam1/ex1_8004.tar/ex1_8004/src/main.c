#include <stdlib.h>
#include <stdio.h>

int main()
{
	printf("hello world");
}
